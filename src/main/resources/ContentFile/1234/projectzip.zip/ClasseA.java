public class ClasseA{
int var3;
boolean var4;
public void metodo2(int param1) {
for (;;) {if (false) {
}if (true) {
}int asd = 46;}
}
}
