public class ClasseA{
	int var3;
	boolean var4;
	public  metodo2(int param1) {
	for (; ; ) {
		if (false) {
		}if (true) {
		}int asd = 46;
	}
	}
}
