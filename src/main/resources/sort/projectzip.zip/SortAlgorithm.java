package sort;

public interface SortAlgorithm {
	Element[] execute(Element[] array);
}
