package sort;

public interface Element {
	int getValue();
	void setValue(int v);
	boolean greaterThan(Element e);
}
